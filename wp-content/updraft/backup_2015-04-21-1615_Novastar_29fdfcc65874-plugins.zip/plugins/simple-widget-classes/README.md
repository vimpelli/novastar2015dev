# Simple Widget Classes

WordPress plugin to provide a text input for all widgets to add a custom class for that widget.

![Image of Simple Widget Classes in Action](https://dl.dropboxusercontent.com/u/15493131/plugins/simple-widgets-ckasees/simple-widget-classes.png)
